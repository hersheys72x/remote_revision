﻿using correspondenciaNetCore.Models;
using correspondenciaNetCore.Servicios;
using Microsoft.AspNetCore.Mvc;
using Org.BouncyCastle.Asn1;

namespace correspondenciaNetCore.Controllers
{
    public class AreaController : Controller
    {
        private readonly IRepositorioAreas repositorioAreas;

        public AreaController(IRepositorioAreas repositorioAreas)
        {
            this.repositorioAreas = repositorioAreas;
        }

        public async Task<IActionResult> Index()
        {
            var areasTot = await repositorioAreas.Todos();
            return View(areasTot);
        }

        public IActionResult Crear()
        {
            return View();  
        }

        [HttpPost]
        public async Task<IActionResult> Crear(AreaCLS _areaX)
        {
            if(!ModelState.IsValid)
            {
                return View(_areaX);
            }
            //- verifica duplicidad en la clave y área
            var yaExisteClave = await repositorioAreas.ExisteClave(_areaX.Clave);
            if(yaExisteClave)
            {
                ModelState.AddModelError(nameof(_areaX.Clave),$"La clave {_areaX.Clave}, ya se encuentra capturada");
                return View(_areaX);
            }
                       
           //-
            await repositorioAreas.Crear(_areaX);
            return RedirectToAction("Index");
        }

        #region no funcionó el remote de la clase
        //[HttpGet]
        //public async Task<IActionResult> VerificaClaveExiste(string clave)
        //{
        //    var yaExisteClave= await repositorioAreas.ExisteClave(clave.Trim());
        //    if(yaExisteClave)
        //    {
        //        return Json($"La clave {clave} ya existe, ¡verifíquelo por favor!");
        //    }
        //    return Json(true);
        //}
        #endregion


        [HttpGet]
        public async Task<IActionResult> Editar(int id)
        {
            var buscaXId = await repositorioAreas.BuscaPorId(id);
            if(buscaXId is null)
            {
                return RedirectToAction("NoEncontrado", "Home");   
            }
            return View(buscaXId);
        }

        [HttpPost]
        public async Task<IActionResult> Editar(AreaCLS areaX)
        {
            var buscaXId = await repositorioAreas.BuscaPorId(areaX.IdArea);
            if (buscaXId is null)
            {
                return RedirectToAction("NoEncontrado", "Home");
            }
            await repositorioAreas.Actualizar(areaX);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Borrar(int id)
        {
            var buscaArea = await repositorioAreas.BuscaPorId(id);
            if(buscaArea is null)
            {
                return RedirectToAction("NoEncontrado", "Home");
            }
            return View(buscaArea); 
        }

        [HttpPost]
        public async Task<IActionResult> BorraArea(AreaCLS borrax)
        {
            var buscaArea= await repositorioAreas.BuscaPorId(borrax.IdArea);
            if (buscaArea is null)
            {
                return RedirectToAction("NoEncontrado", "Home");
            }
            await repositorioAreas.Borrar(borrax.IdArea);
            return RedirectToAction("Index");
        }



    }
}
