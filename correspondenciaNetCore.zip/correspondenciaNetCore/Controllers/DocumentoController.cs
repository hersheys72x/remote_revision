﻿using correspondenciaNetCore.Servicios;
using correspondenciaNetCore.Models;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;

namespace correspondenciaNetCore.Controllers
{
    public class DocumentoController : Controller
    {
        private readonly IRepositorioDocu repositorioDocu;
        public DocumentoController(IRepositorioDocu repositorioDocu) 
        {
            this.repositorioDocu = repositorioDocu;
        }


        // todos
        public async Task<IActionResult> Index()
        {
            var docuTot = await repositorioDocu.GetTodos();
            return View(docuTot);
        }


        // crear
        [HttpGet]
        public IActionResult Crear()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Crear(documentosCLS docuX)
        {
            if(!ModelState.IsValid)
            {
                return View(docuX);
            }
            //verifica doplidicades
            var yaExisteDocu = await repositorioDocu.ExisteDocumento(docuX.Documento);
            if(yaExisteDocu)
            {
                ModelState.AddModelError(nameof(docuX.Documento),$"El tipo de documento {docuX.Documento}, ya existe");
                return View(docuX);
            }
            //verifica doplidicades

            await repositorioDocu.Crear(docuX);
            return RedirectToAction("Index");
        }

        //editar
        [HttpGet]
        public async Task<IActionResult> Editar(int id)
        {
            //busca el ID
            var buscaDoc = await repositorioDocu.BuscaporId(id);
            if(buscaDoc is null)
            {
                return RedirectToAction("NoEncontrado", "Home");
            }
            return View(buscaDoc);
        }

        [HttpPost]
        public async Task<IActionResult> Editar(documentosCLS docuX)
        {
            //busca el Id
            var buscaDoc = await repositorioDocu.BuscaporId(docuX.Id_docu);
            if(buscaDoc is null)
            {
                return RedirectToAction("NoEncontrado", "Home");
            }
            await repositorioDocu.Actualiza(docuX);
            return RedirectToAction("Index");
        }

        //borra
        [HttpGet]
        public async Task<IActionResult> Borrar(int id)
        {
            var buscaDocu = await repositorioDocu.BuscaporId(id);
            if(buscaDocu is null)
            {
                return RedirectToAction("NoEncontrado", "Home");   
            }
            return View(buscaDocu);
        }

        [HttpPost]
        public async Task<IActionResult> Borrar(documentosCLS docuX)
        {
            var buscaDocu = await repositorioDocu.BuscaporId(docuX.Id_docu);
            if(buscaDocu is null)
            {
                return RedirectToAction("NoEncontrado", "Home");
            }
            await repositorioDocu.Borrar(docuX.Id_docu);
            return RedirectToAction("Index");
        }
    }
}
