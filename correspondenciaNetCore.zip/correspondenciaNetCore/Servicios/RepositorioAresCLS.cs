﻿using correspondenciaNetCore.Models;
using Dapper;
using Org.BouncyCastle.Asn1;
using System.Data;

namespace correspondenciaNetCore.Servicios
{
    public interface IRepositorioAreas
    {
        Task Actualizar(AreaCLS areaX);
        Task Borrar(int id);
        Task<AreaCLS> BuscaPorId(int id);
        Task Crear(AreaCLS areaX);
        Task<bool> ExisteClave(string clave);
        Task<IEnumerable<AreaCLS>> Todos();
    }
    public class RepositorioAresCLS : IRepositorioAreas
    {
        private readonly string connectionString;
        public RepositorioAresCLS(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<IEnumerable<AreaCLS>> Todos()
        {
            using var connection= new MySql.Data.MySqlClient.MySqlConnection(connectionString);
            return await connection.QueryAsync<AreaCLS>(@"select * from area", commandType: CommandType.Text);
        }

        public async Task Crear(AreaCLS areaX) 
        {
            using var connection = new MySql.Data.MySqlClient.MySqlConnection(connectionString);
            var id= await connection.QuerySingleAsync<int>(@"insert into area (clave, areas, jefe, cargo) values (@clave, @areas, @jefe, @cargo); SELECT LAST_INSERT_ID();", areaX);
            areaX.IdArea = id;  
        }

        public async Task<bool> ExisteClave(string clave)
        {
            using var connection= new MySql.Data.MySqlClient.MySqlConnection(connectionString);
            var existeClave = await connection.QueryFirstOrDefaultAsync<int>(@"select 1 from area where CLAVE=@Clave", new {clave});
            return existeClave == 1;
        }

        public async Task Actualizar(AreaCLS areaX)
        {
            using var connection= new MySql.Data.MySqlClient.MySqlConnection(connectionString);
            await connection.ExecuteAsync(@"update area set clave=@Clave, areas=@Areas, jefe=@Jefe, cargo=@Cargo where idarea=@IdArea", areaX);
        }

        public async Task<AreaCLS> BuscaPorId(int id)
        {
            using var connection = new MySql.Data.MySqlClient.MySqlConnection(connectionString);
            return await connection.QueryFirstOrDefaultAsync<AreaCLS>(@"select * from area where idarea=@Id", new { id });
        }

        public async Task Borrar(int id)
        {
            using var connection= new MySql.Data.MySqlClient.MySqlConnection(connectionString);
            await connection.ExecuteAsync(@"delete from area where idarea=@Id", new { id });
        }

               

    }
}
