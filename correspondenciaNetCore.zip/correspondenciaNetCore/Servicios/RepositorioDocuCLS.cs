﻿using correspondenciaNetCore.Models;
using Dapper;
using MySqlConnector;
using Org.BouncyCastle.Asn1.Esf;
//-
using System.Data;


namespace correspondenciaNetCore.Servicios
{

    public interface IRepositorioDocu
    {
        Task Actualiza(documentosCLS docuX);
        Task Borrar(int id);
        Task<documentosCLS> BuscaporId(int id);
        Task Crear(documentosCLS docuX);
        Task<bool> ExisteDocumento(string documento);
        Task<IEnumerable<documentosCLS>> GetTodos();
    }

    public class RepositorioDocuCLS : IRepositorioDocu
    {
        private readonly string connectionString;
        public RepositorioDocuCLS(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        // Todos
        public async Task<IEnumerable<documentosCLS>> GetTodos()
        {
            using var conexion= new MySql.Data.MySqlClient.MySqlConnection(connectionString);
            return await conexion.QueryAsync<documentosCLS>(@"select * from documentos order by documento", commandType: CommandType.Text);
        }

        // busca por id
        public async Task<documentosCLS> BuscaporId(int id)
        {
            using var conexion = new MySql.Data.MySqlClient.MySqlConnection(connectionString);
            return await conexion.QueryFirstOrDefaultAsync<documentosCLS>(@"select * from documentos where id_docu=@Id", new { id });
        }

        //busca documento existente (duplicidades)
        public async Task<bool> ExisteDocumento(string documento)
        {
            using var conexion = new MySql.Data.MySqlClient.MySqlConnection(connectionString);
            var existeDocu = await conexion.QueryFirstOrDefaultAsync<int>(@"select 1 from documentos where documento=@Documento", new { documento });
            return existeDocu ==1; 
        }
        // agregar 
        public async Task Crear(documentosCLS docuX)
        {
            using var conexion = new MySql.Data.MySqlClient.MySqlConnection(connectionString);
            var id = await conexion.QuerySingleAsync<int>(@"insert into documentos (documento) values (@Documento); SELECT LAST_INSERT_ID();", docuX);
            docuX.Id_docu = id; 
        }

        //actualiza
        public async Task Actualiza(documentosCLS docuX)
        {
            using var conexion= new MySql.Data.MySqlClient.MySqlConnection(connectionString);
            await conexion.ExecuteAsync(@"update documentos set documento=@Documento where id_docu=@id_docu", docuX);
        }

        //borra
        public async Task Borrar(int id)
        {
            using var conexion = new MySql.Data.MySqlClient.MySqlConnection(connectionString);
            await conexion.ExecuteAsync(@"delete from documentos where id_docu=@Id", new {id});
        }
    }
}
