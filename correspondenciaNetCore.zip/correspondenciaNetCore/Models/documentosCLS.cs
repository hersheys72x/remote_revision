﻿using System.ComponentModel.DataAnnotations;

namespace correspondenciaNetCore.Models
{
    public class documentosCLS
    {
        public int Id_docu {  get; set; }
        [Required(ErrorMessage ="La descripción de documento es requerido")]
        public string Documento {  get; set; }  
    }
}

