﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;


namespace correspondenciaNetCore.Models
{
    public class AreaCLS
    {
        public int IdArea { get; set; }
        [Required(ErrorMessage = "La clave es requerido")]
        //[Remote(action: "VerificaClaveExiste", controller: "Area")] // no funciono el remote
        public string Clave { get; set; }
        [Required(ErrorMessage ="El nombre del área es requerido")]
        public string Areas { get; set;}
        [Required(ErrorMessage = "El nombre del resposable o jefe es requerido")]
        public string Jefe { get; set; }
        [Required(ErrorMessage = "El cargo es requerido")]
        public string Cargo { get; set; }   
    }
}
